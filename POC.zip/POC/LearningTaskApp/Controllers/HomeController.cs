using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LearningTaskApp.Models;
using LearningTaskApp.Services;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LearningTaskApp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    public List<LearningTask>  tasks = new List<LearningTask>(); 

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;        
    }

    // GET: LearningTasks
    public IActionResult Index()
    {
        var task = LearningRepository.GetAllTasks();
        return View(task);
    }

    // GET: LearningTask/Details/3
    public IActionResult Details(int id)
    {
        var task = LearningRepository.GetTaskById(id);
            if (task == null)
            {
                TempData["ErrorMessage"] = "Task not Found";
                return RedirectToAction(nameof(Index));
            }
            return View(task);
    }

    //Create Method

    // GET: LearningTask/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: LearningTask/Create
    [HttpPost]
    public IActionResult Create(LearningTask taskDetails)
    {
        var task = LearningRepository.GetAllTasks();
        if (task.Any(t => t.TaskName == taskDetails.TaskName))
        {
            TempData["ErrorMessage"] = " This  "+ taskDetails.TaskName +"  Task already exists ";
            return RedirectToAction(nameof(Index));
        } 
        if (ModelState.IsValid)
        { 
            LearningRepository.AddTask(taskDetails);
            TempData["SuccessMessage"] = "Task Create successfully!";
            return RedirectToAction(nameof(Index));
        }
        return View(taskDetails); 
    }

    // GET: LearningTask/Edit/5
    public IActionResult Edit(int id)
    {
        var task = LearningRepository.GetTaskById(id);
        if(task == null)
        {
            NotFound();
        }

        task.StatusOptions = Enum.GetValues(typeof(TasksStatus))
                            .Cast<TasksStatus>()
                            .Select(s => new SelectListItem
                            {
                                Text = s.ToString(),
                                Value = ((int)s).ToString()
                            })
                            .ToList();
       
        return View(task);
    }

    // POST: LearningTask/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(int id, LearningTask taskDetails)
    {
        if (id != taskDetails.Id) 
        { 
   	      TempData["ErrorMessage"] = "Task not Found";
          return RedirectToAction(nameof(Index));
        }

        if (ModelState.IsValid)
        {
            LearningRepository.UpdateProduct(taskDetails);
            TempData["SuccessMessage"] = "Task Edit successfully!";
            return RedirectToAction(nameof(Index));
        }
        return View(taskDetails);
    }

    // GET: LearningTask/Delete/5
    public IActionResult Delete(int id)
    {
        var task = LearningRepository.GetTaskById(id);
        if (task == null)
        {
            TempData["ErrorMessage"] = "Task not Found";
            return RedirectToAction(nameof(Index));
        }
        return View(task);
    }

    // POST: LearningTask/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public IActionResult DeleteConfirmed(int id)
    {
        bool deleted = LearningRepository.DeleteTask(id);
        if(deleted)
        {
            TempData["SuccessMessage"] = "Task deleted successfully!";
            return RedirectToAction("Index");
        }
        else
        {
            TempData["ErrorMessage"] = " Deletion of completed tasks only .";
            return RedirectToAction("Index");
        }
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
