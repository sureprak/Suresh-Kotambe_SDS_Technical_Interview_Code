using System.Collections.Generic;
using System.Linq;
using LearningTaskApp.Models;
using static LearningTaskApp.Models.LearningTask;

namespace LearningTaskApp.Services
{
    public static class LearningRepository
    {
        private static List<LearningTask> tasks = new List<LearningTask>
        {
            new LearningTask { Id = 1, TaskName = "C#", Priority= 1, Status = TasksStatus.NotStarted },
            new LearningTask { Id = 2, TaskName = "ASP .Net Core", Priority = 1, Status = TasksStatus.NotStarted }
        };

        public static List<LearningTask> GetAllTasks() => tasks;

        public static LearningTask? GetTaskById(int id) => tasks.FirstOrDefault(t => t.Id == id);

        public static void AddTask(LearningTask task)
        {
            task.Id = tasks.Max(p => p.Id) + 1;  // Auto-increment Id
            tasks.Add(task);
        }

        public static void UpdateProduct(LearningTask task)
        {
            var existingTask = tasks.FirstOrDefault(p => p.Id == task.Id);
            if (existingTask != null)
            {
                existingTask.TaskName = task.TaskName;
                existingTask.Priority = task.Priority;
                existingTask.Status = task.Status;
            }
        }

        public static bool DeleteTask(int id)
        {
             var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                if(task.Status == TasksStatus.Completed)
                {
                    tasks.Remove(task);
                    return true;
                }
                else
                {
                    return false;
                }             
            }
            return true;
        }
    }
}