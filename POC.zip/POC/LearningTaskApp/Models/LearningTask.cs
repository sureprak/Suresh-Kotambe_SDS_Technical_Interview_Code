using System.Web;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LearningTaskApp.Models
{
    public enum TasksStatus 
    {
        NotStarted,
        InProgress,
        Completed 
    }
    public class LearningTask
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(50, ErrorMessage = " Name cannot be longer than 50 characters.")]
   		public string? TaskName { get; set; }

 		 [Required(ErrorMessage = "Priority is required.")]
  		public int  Priority { get; set; }

  		 [Required(ErrorMessage = "Status is required.")]
 		public TasksStatus Status { get; set; }
        public List<SelectListItem>? StatusOptions { get; set; }
    }

    
}

    

